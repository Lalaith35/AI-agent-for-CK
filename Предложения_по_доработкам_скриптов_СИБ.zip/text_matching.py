# shared/text_matching.py

import re
from typing import Any

from nltk.stem.snowball import SnowballStemmer

stemmer = SnowballStemmer("russian")


def normalize_text(text: str) -> str:
    if not text:
        return ""
    text = text.lower().replace("ё", "е")
    text = re.sub(r"[^\w\s-]", " ", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text: str) -> list[str]:
    return [token for token in normalize_text(text).split() if token]


def stem_list(words: list[str]) -> list[str]:
    return [stemmer.stem(word) for word in words]


def _contains_exact_phrase(text: str, phrase: str) -> bool:
    normalized_text = normalize_text(text)
    normalized_phrase = normalize_text(phrase)
    if not normalized_text or not normalized_phrase:
        return False
    pattern = rf"\b{re.escape(normalized_phrase)}\b"
    return bool(re.search(pattern, normalized_text, flags=re.UNICODE))


def _all_keyword_stems_in_field(field_stems: set[str], keyword_stems: list[str]) -> bool:
    if not keyword_stems:
        return False
    return all(stem in field_stems for stem in keyword_stems)


def match_keywords(
    title: str,
    full_text: str,
    keywords: list[str],
) -> dict[str, Any]:
    title_tokens = tokenize(title)
    full_tokens = tokenize(full_text)

    title_stems = set(stem_list(title_tokens))
    full_stems = set(stem_list(full_tokens))

    matched_keywords: list[str] = []
    total_score = 0

    for keyword in keywords:
        kw_tokens = tokenize(keyword)
        if not kw_tokens:
            continue

        kw_stems = stem_list(kw_tokens)

        exact_title = _contains_exact_phrase(title, keyword)

        all_in_title = _all_keyword_stems_in_field(title_stems, kw_stems)
        all_in_full = _all_keyword_stems_in_field(full_stems, kw_stems)

        keyword_score = 0

        if exact_title:
            keyword_score += 4
        elif all_in_title:
            keyword_score += 3

        if len(kw_tokens) >= 2 and all_in_full:
            keyword_score += 1

        if keyword_score > 0:
            matched_keywords.append(keyword)
            total_score += keyword_score

    return {
        "matched_keywords": matched_keywords,
        "score": total_score,
        "is_match": total_score > 0,
    }