# parsers/banki.py

import re
import time
from datetime import datetime, timedelta, date
from typing import Optional
from urllib.parse import urljoin

import pandas as pd
import requests
from bs4 import BeautifulSoup

from modules.text_matching import match_keywords

USER_AGENT = (
    "NewsMonitoringBot/1.0 "
    "(public-news parser for research purposes)"
)

BASE_URL = "https://www.banki.ru"
LIST_URL = "https://www.banki.ru/news/lenta/"

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
}

BACKOFF_DELAYS = [1, 2, 4, 8]

DIGEST_EXCEPTIONS_LIST = ['за неделю', 'за день', 'лучшие статьи недели', 'новости недели']

def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(HEADERS)
    return session


def safe_get(
    session: requests.Session,
    url: str,
    *,
    timeout: int = 30,
) -> Optional[requests.Response]:
    for attempt, delay in enumerate(BACKOFF_DELAYS, start=1):
        try:
            response = session.get(url, timeout=timeout)
            if response.status_code == 429:
                time.sleep(delay)
                continue
            response.raise_for_status()
            return response
        except requests.RequestException:
            if attempt == len(BACKOFF_DELAYS):
                return None
    return None


def normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def prepare_result(rows: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(rows, columns=[
        "Дата новости",
        "Заголовок статьи",
        "Полный текст",
        "Ссылка на источник",
        "Ключевые слова"
    ])
    if not df.empty:
        df = df.drop_duplicates(subset=["Ссылка на источник"]).reset_index(drop=True)
    return df


def date_window(days: int) -> tuple[date, date]:
    today = datetime.now().date()
    start = today - timedelta(days=max(days, 1) - 1)
    return start, today


def build_list_url(page: int) -> str:
    if page <= 1:
        return LIST_URL
    return f"{LIST_URL}?page={page}"


def parse_listing_html(html: str) -> list[dict]:
    try:
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text("\n", strip=True)
        lines = [line.strip() for line in text.splitlines() if line.strip()]
    except Exception:
        return []

    items: list[dict] = []
    current_date: Optional[date] = None
    i = 0

    while i < len(lines):
        line = lines[i]

        if re.fullmatch(r"\d{2}\.\d{2}\.\d{4}", line):
            try:
                current_date = datetime.strptime(line, "%d.%m.%Y").date()
            except ValueError:
                current_date = None
            i += 1
            continue

        if current_date and re.fullmatch(r"\d{2}:\d{2}", line):
            title = lines[i + 1] if i + 1 < len(lines) else ""
            if title:
                items.append({
                    "date": current_date,
                    "title": normalize_whitespace(title),
                    "url": None,
                    "preview_text": "",
                })
            i += 2
            continue

        i += 1

    title_to_index: dict[str, int] = {}
    for idx, item in enumerate(items):
        title_to_index.setdefault(item["title"], idx)

    for a in soup.find_all("a", href=True):
        href = a.get("href", "")
        title = normalize_whitespace(a.get_text(" ", strip=True))

        if not title:
            continue

        if "/news/lenta/?id=" in href or "/news/lenta/" in href:
            abs_url = urljoin(BASE_URL, href)
            idx = title_to_index.get(title)
            if idx is not None and items[idx]["url"] is None:
                items[idx]["url"] = abs_url

    return [item for item in items if item.get("date") and item.get("title") and item.get("url")]


def collect_listing_items(
    session: requests.Session,
    days: int,
    max_pages: int = 20,
) -> list[dict]:
    start_date, _ = date_window(days)
    collected: list[dict] = []

    for page in range(1, max_pages + 1):
        url = build_list_url(page)
        response = safe_get(session, url)
        if response is None:
            break

        page_items = parse_listing_html(response.text)
        if not page_items:
            break

        collected.extend(page_items)

        page_dates = [item["date"] for item in page_items if item.get("date")]
        if not page_dates:
            break

        oldest_date_on_page = min(page_dates)
        if oldest_date_on_page < start_date:
            break

    return collected


def extract_full_text(session: requests.Session, url: str) -> str:
    response = safe_get(session, url)
    if response is None:
        return ""

    try:
        soup = BeautifulSoup(response.text, "html.parser")
        article = soup.find("article") or soup.find("main") or soup
        paragraphs = [
            normalize_whitespace(p.get_text(" ", strip=True))
            for p in article.find_all("p")
        ]
        paragraphs = [p for p in paragraphs if p]
        return "\n".join(paragraphs)
    except Exception:
        return ""


def parse(keywords: list[str], days: int = 1) -> pd.DataFrame:
    session = build_session()
    start_date, end_date = date_window(days)
    rows: list[dict] = []

    items = collect_listing_items(session, days=days)

    for item in items:
        pub_date = item.get("date")
        title = item.get("title", "")
        url = item.get("url", "")

        if not pub_date or not (start_date <= pub_date <= end_date):
            continue

        # =============================
        # Проверка на признак дайджеста
        # =============================

        is_digest = False

        for digest in DIGEST_EXCEPTIONS_LIST:
            if digest in title.lower():
                is_digest = True
                break

        if is_digest:
            continue

        # ==========================================
        # Получаем текст статьи
        # Убираем блок рекомендаций "Читать по теме"
        # ==========================================

        full_text = extract_full_text(session, url)

        full_text = full_text.split("Читать по теме", 1)[0].rstrip()

        # =========================
        # Поиск по ключевым словам
        # =========================

        match_info = match_keywords(
            title=title,
            full_text=full_text,
            keywords=keywords,
        )

        if not match_info["is_match"]:
            continue

        print(f"✅ Найдена новость {pub_date} '{title}' ({url})")

        # =================
        # Собираем строку
        # =================

        rows.append({
            "Дата новости": pub_date.strftime("%Y-%m-%d"),
            "Заголовок статьи": title,
            "Полный текст": full_text,
            "Ссылка на источник": url,
            "Ключевые слова": match_info['matched_keywords']
        })

    return prepare_result(rows)